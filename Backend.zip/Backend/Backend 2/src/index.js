// require('dotenv').config({path: './env'})
import dotenv from "dotenv"
import connectDB from './db/index.js'

dotenv.config({
    path:'./.env'
})



connectDB()
.then(()=>{
    // we have used this to prevent any issue for production 
    app.on("error",(err)=>{
        console.log("ERROR: ",err);
        throw err
    })
    app.listen(process.env.PORT || 8000, () => {
        console.log(`⚙️ Server is running on port ${process.env.PORT}`)
    })
})
.catch((err)=>{
    console.log("MongoDB connection field !!!  ",err);
    
})











/** 
import express from 'express'
const app = express()
// using IIFE
;(async()=>{
    try {
        await mongoose.connect(`${process.env.MONGODB_URI}/${DB_NAME}`)
        app.on("error", (error) => {
            console.log("ERROR",error);
            throw error
            
        })
        app.listen(process.env.PORT, () => {
            console.log(`App is listening in port ${process.env.PORT}`);            
        })

    } catch (error) {
        console.log("Error: ",error);
        
    }
})(

)
**/